package com.smartersvision.home_services_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
